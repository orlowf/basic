import pandas as pd

def process_training_data(file_path):
    try:
        dados_cru = pd.read_csv(file_path)
        if 'Nome' not in dados_cru.columns or 'Treino' not in dados_cru.columns:
            raise ValueError("CSV must contain 'Nome' and 'Treino' columns")
        df = (dados_cru.assign(Treino=dados_cru['Treino'].str.split(" e "))
              .explode('Treino')
              .reset_index(drop=True)[['Nome', 'Treino']])
        df['Treino'] = df['Treino'].str.strip()
        return df
    except FileNotFoundError:
        print(f"Error: File {file_path} not found")
        return None
    except Exception as e:
        print(f"Error: {str(e)}")
        return None