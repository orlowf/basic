from data_processing import process_training_data
import pandas as pd

if __name__ == "__main__":
    file_path = "src/arquivo/Treinos_Academia_Atualizado.csv"
    
    df = process_training_data(file_path)
    print(f"Tipo do df: {type(df)}")
    
    if df is None:
        print("Erro: o DataFrame principal não foi carregado corretamente.")
        exit(1)
    
dados = {
    'Nome': [],
    'Peito': [],
    'Costas': [],
    'Biceps': [],
    'Triceps': [],
    'Perna': [],
    'Aula Coletiva': [],
    'Pontos': []
}

# Create the DataFrame
df_new = pd.DataFrame(dados)
for index,row in df.iterrows():
    if row['Nome'] in df_new['Nome'].values:
        if row['Treino'] == 'Peito':
            df_new.loc[df_new['Nome'] == row['Nome'], 'Peito'] += 1
        elif row['Treino'] == 'Costas':
            df_new.loc[df_new['Nome'] == row['Nome'], 'Costas'] += 1
        elif row['Treino'] == 'Bíceps':
            df_new.loc[df_new['Nome'] == row['Nome'], 'Biceps'] += 1
        elif row['Treino'] == 'Tríceps':
            df_new.loc[df_new['Nome'] == row['Nome'], 'Triceps'] += 1
        elif row['Treino'] == 'Perna':
            df_new.loc[df_new['Nome'] == row['Nome'], 'Perna'] += 1
    else:
        nova_linha = pd.DataFrame({'Nome': [row['Nome']],
                           'Peito': [0],
                           'Costas': [0],
                           'Biceps': [0],
                           'Triceps': [0],
                           'Perna': [0],
                           'Aula Coletiva': [0],
                           'Pontos': [0]})
        if row['Treino'] == 'Peito':
            nova_linha['Peito'] = 1
        elif row['Treino'] == 'Costas':
            nova_linha['Costas'] = 1
        elif row['Treino'] == 'Biceps':
            nova_linha['Biceps'] = 1
        elif row['Treino'] == 'Triceps':
            nova_linha['Triceps'] = 1
        elif row['Treino'] == 'Perna':
            nova_linha['Perna'] = 1
        else:
            print(f"Treino {row['Treino']} não reconhecido.")
            continue
        df_new = pd.concat([df_new, nova_linha], ignore_index=True)
modalidades = pd.read_csv('src/arquivo/Alunos_com_Modalidades.csv')

for i, r in modalidades.iterrows():
    if r['Nome'] in df_new['Nome'].values:
        df_new.loc[df_new['Nome'] == r['Nome'], 'Aula Coletiva'] += 3
    else:
        nova_linha = pd.DataFrame({'Nome': [r['Nome']],
                                   'Peito': [0],
                                   'Costas': [0],
                                   'Biceps': [0],
                                   'Triceps': [0],
                                   'Perna': [0],
                                   'Aula Coletiva': [3],
                                   'Pontos': [0]})
        df_new = pd.concat([df_new, nova_linha], ignore_index=True)



df_new['Pontos'] = df_new[['Peito', 'Costas', 'Biceps', 'Triceps', 'Perna', 'Aula Coletiva']*10].sum(axis=1)
print(df_new)
# Ranquear os alunos em ordem decrescente de pontos
ranking = df_new.sort_values(by='Pontos', ascending=False).reset_index(drop=True)

# Exibir os 10 primeiros colocados
print(ranking.head(30))

