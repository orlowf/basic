import pandas as pd
import os
from modules import (
    create_empty_dataframe,
    process_training_row,
    process_modalidades,
    calculate_points,
    get_ranking,
    watch_directory,
    get_file_paths,
    get_csv_files
)
from modules.weekly_scoring import process_weekly_scoring, print_weekly_report

def process_single_file(file_path):
    """Process a single CSV file.
    
    Args:
        file_path (Path): Path to the CSV file to process
    """
    print(f"\nProcessando arquivo: {file_path}")
    try:
        # Read the CSV file
        df = pd.read_csv(file_path)
        print(f"Arquivo carregado: {len(df)} registros")
        print("\nPrimeiras linhas do arquivo:")
        print(df.head())
        
        # Check if it's a training file or modalidades file
        if 'Treino' in df.columns:
            print("\nArquivo de treinos detectado")
            # Process as training file
            df_new = create_empty_dataframe()
            for _, row in df.iterrows():
                df_new = process_training_row(row, df_new)
            
            # Calculate points
            df_new = calculate_points(df_new)
            
            # Process weekly scoring
            print("\nProcessando pontuação semanal...")
            _, weekly_report = process_weekly_scoring(df)
            
            # Apply weekly bonus points
            for _, row in weekly_report.iterrows():
                student = row['Nome']
                if student in df_new['Nome'].values:
                    df_new.loc[df_new['Nome'] == student, 'Pontos'] += row['Bônus']
            
            print("\nDataFrame processado:")
            print(df_new)
            
            # Print weekly report
            print_weekly_report(weekly_report)
            
            # Print ranking
            print("\n=== Ranking dos Alunos ===")
            ranking = df_new.sort_values('Pontos', ascending=False)[['Nome', 'Pontos']]
            ranking.index = range(1, len(ranking) + 1)  # Reset index to start from 1
            print(ranking)
            
        elif 'Modalidade' in df.columns:
            print("\nArquivo de modalidades detectado")
            # Process as modalidades file
            df_new = create_empty_dataframe()
            df_new = process_modalidades(df, df_new)
            
            # Calculate points
            df_new = calculate_points(df_new)
            
            print("\nDataFrame processado:")
            print(df_new)
            
            # Print ranking
            print("\n=== Ranking dos Alunos ===")
            ranking = df_new.sort_values('Pontos', ascending=False)[['Nome', 'Pontos']]
            ranking.index = range(1, len(ranking) + 1)  # Reset index to start from 1
            print(ranking)
        else:
            print("\nEstrutura do arquivo não reconhecida")
            print("Colunas encontradas:", df.columns.tolist())
            
    except Exception as e:
        print(f"Erro ao processar arquivo: {str(e)}")

def main():
    # Directory containing CSV files
    csv_directory = r"C:\Users\felip\OneDrive\Documentos\basic\basic\.venv\arquivo"
    
    print(f"\nMonitorando diretório: {csv_directory}")
    
    # Process existing files first
    print("\nProcessando arquivos existentes...")
    for file_path in get_csv_files(csv_directory):
        process_single_file(file_path)
    
    print("\nAguardando por novas alterações...")
    print("Pressione Ctrl+C para sair")
    
    try:
        for file_path in watch_directory(csv_directory):
            print(f"\nNovo arquivo detectado: {file_path}")
            print(f"Última modificação: {pd.Timestamp(os.path.getmtime(file_path), unit='s')}")
            process_single_file(file_path)
            
    except KeyboardInterrupt:
        print("\nPrograma encerrado pelo usuário.")
    except Exception as e:
        print(f"\nErro inesperado: {str(e)}")

if __name__ == "__main__":
    main()


