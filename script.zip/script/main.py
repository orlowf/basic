import pandas as pd
import os
from modules import (
    create_empty_dataframe,
    process_training_row,
    process_modalidades,
    calculate_points
)
from modules.weekly_scoring import process_weekly_scoring, print_weekly_report
from modules.database_handler import DatabaseHandler
from modules.file_handler import CSVHandler
import glob
import time
from watchdog.observers import Observer

# Directory containing CSV files
CSV_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "arquivo")

def process_single_file(file_path, db_handler):
    """Process a single CSV file and update the database."""
    try:
        print(f"\nProcessando arquivo: {file_path}")
        
        # Load and process the CSV file
        df = pd.read_csv(file_path)
        print(f"Registros carregados: {len(df)}")
        print("Colunas encontradas:", df.columns.tolist())
        
        # Save to database
        print("\nSalvando dados no banco...")
        db_handler.save_training_data(df)
        
        # Process training data
        print("\nProcessando dados de treino...")
        training_df = create_empty_dataframe()
        for _, row in df.iterrows():
            training_df = process_training_row(row, training_df)
        print(f"Registros de treino processados: {len(training_df)}")
        
        # Process modalities
        print("\nProcessando modalidades...")
        modalities_df = create_empty_dataframe()  # Create new DataFrame for modalidades
        modalities_df = process_modalidades(training_df, modalities_df)
        print(f"Modalidades processadas: {len(modalities_df)}")
        
        # Calculate points
        print("\nCalculando pontos...")
        points_data = calculate_points(modalities_df)
        print(f"Pontos calculados para {len(points_data)} alunos")
        
        # Update points in database
        print("\nAtualizando pontos no banco...")
        db_handler.update_points(points_data)
        
        # Save points history
        print("\nSalvando histórico de pontos...")
        db_handler.save_points_history(points_data, os.path.basename(file_path))
        
        # Get current points
        print("\nRecuperando pontuação atual...")
        current_points = db_handler.get_points_history(limit=50)
        
        # Get ranking
        print("\nRecuperando ranking...")
        ranking = db_handler.get_ranking()
        
        return True
        
    except Exception as e:
        print(f"\nErro ao processar arquivo {file_path}: {str(e)}")
        print("Detalhes do erro:")
        import traceback
        print(traceback.format_exc())
        return False

def main():
    """Main function to process CSV files and monitor directory."""
    try:
        # Initialize database handler
        db_handler = DatabaseHandler()
        
        # Process existing files
        csv_files = glob.glob(os.path.join(CSV_DIR, "*.csv"))
        if csv_files:
            print(f"\nEncontrados {len(csv_files)} arquivos CSV para processar")
            for file_path in csv_files:
                process_single_file(file_path, db_handler)
        else:
            print("\nNenhum arquivo CSV encontrado para processar")
        
        # Monitor directory for new files
        print("\nMonitorando diretório para novos arquivos...")
        print("O programa está rodando e aguardando novos arquivos CSV.")
        print("Pressione Ctrl+C para encerrar o programa.")
        print("\nStatus: Ativo - Aguardando arquivos...")
        
        observer = Observer()
        event_handler = CSVHandler(db_handler, process_single_file)
        observer.schedule(event_handler, CSV_DIR, recursive=False)
        observer.start()
        
        try:
            while True:
                time.sleep(1)
                # Print a dot every 5 seconds to show the program is still running
                if int(time.time()) % 5 == 0:
                    print(".", end="", flush=True)
        except KeyboardInterrupt:
            observer.stop()
            print("\n\nMonitoramento interrompido pelo usuário")
        
        observer.join()
        
    except Exception as e:
        print(f"\nErro na execução do programa: {str(e)}")
        print("Detalhes do erro:")
        import traceback
        print(traceback.format_exc())

if __name__ == "__main__":
    main()


