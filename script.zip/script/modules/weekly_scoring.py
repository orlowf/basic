import pandas as pd
from datetime import datetime, timedelta

# Configurable parameters
POINTS_2_WEEKS = 50
POINTS_3_WEEKS = 120
POINTS_4_WEEKS = 200
MIN_DAYS_PER_WEEK = 3

def convert_dates(df):
    """Convert the Date column to datetime format.
    
    Args:
        df (pandas.DataFrame): DataFrame containing the Date column
        
    Returns:
        pandas.DataFrame: DataFrame with converted dates
    """
    try:
        # Check if DataHora column exists
        if 'DataHora' in df.columns:
            df = df.rename(columns={'DataHora': 'Date'})
        elif 'Date' not in df.columns:
            print("Erro: Coluna de data não encontrada. Colunas disponíveis:", df.columns.tolist())
            return None
            
        # Convert to datetime
        df['Date'] = pd.to_datetime(df['Date'])
        return df
    except Exception as e:
        print(f"Erro ao converter datas: {str(e)}")
        return None

def get_week_number(date):
    """Get the week number for a given date.
    
    Args:
        date (datetime): Date to get week number for
        
    Returns:
        int: Week number (1-based)
    """
    return date.isocalendar()[1]

def count_weekly_training_days(df):
    """Count training days per week for each student.
    
    Args:
        df (pandas.DataFrame): DataFrame containing training data
        
    Returns:
        pandas.DataFrame: DataFrame with weekly training counts
    """
    if df is None:
        return pd.DataFrame()
    
    # Convert dates
    df = convert_dates(df)
    if df is None:
        return pd.DataFrame()
    
    # Add week number
    df['Week'] = df['Date'].apply(get_week_number)
    
    # Count unique training days per week
    weekly_counts = df.groupby(['Nome', 'Week'])['Date'].nunique().reset_index()
    weekly_counts.columns = ['Nome', 'Week', 'TrainingDays']
    
    return weekly_counts

def find_consecutive_weeks(weekly_counts):
    """Find consecutive weeks with sufficient training days.
    
    Args:
        weekly_counts (pandas.DataFrame): DataFrame with weekly training counts
        
    Returns:
        dict: Dictionary mapping students to their consecutive week streaks
    """
    streaks = {}
    
    for student in weekly_counts['Nome'].unique():
        student_weeks = weekly_counts[weekly_counts['Nome'] == student].sort_values('Week')
        valid_weeks = student_weeks[student_weeks['TrainingDays'] >= MIN_DAYS_PER_WEEK]
        
        if len(valid_weeks) < 2:
            continue
            
        current_streak = 1
        max_streak = 1
        
        for i in range(1, len(valid_weeks)):
            if valid_weeks.iloc[i]['Week'] - valid_weeks.iloc[i-1]['Week'] == 1:
                current_streak += 1
                max_streak = max(max_streak, current_streak)
            else:
                current_streak = 1
        
        if max_streak >= 2:
            streaks[student] = max_streak
    
    return streaks

def calculate_weekly_bonus(streaks):
    """Calculate bonus points based on consecutive weeks.
    
    Args:
        streaks (dict): Dictionary mapping students to their consecutive week streaks
        
    Returns:
        dict: Dictionary mapping students to their bonus points
    """
    bonuses = {}
    
    for student, streak in streaks.items():
        if streak >= 4:
            bonus = POINTS_4_WEEKS
        elif streak >= 3:
            bonus = POINTS_3_WEEKS
        else:
            bonus = POINTS_2_WEEKS
        bonuses[student] = bonus
    
    return bonuses

def process_weekly_scoring(df):
    """Process weekly training data and calculate bonuses.
    
    Args:
        df (pandas.DataFrame): DataFrame containing training data
        
    Returns:
        tuple: (updated_df, weekly_report)
    """
    # Count weekly training days
    weekly_counts = count_weekly_training_days(df)
    if weekly_counts.empty:
        return df, pd.DataFrame()
    
    # Find consecutive weeks
    streaks = find_consecutive_weeks(weekly_counts)
    
    # Calculate bonuses
    bonuses = calculate_weekly_bonus(streaks)
    
    # Create weekly report
    weekly_report = []
    for student, streak in streaks.items():
        weekly_report.append({
            'Nome': student,
            'Semanas Consecutivas': streak,
            'Bônus': bonuses[student]
        })
    
    # Create a new DataFrame with the same structure as the original
    result_df = df.copy()
    
    # Apply bonus points
    if 'Pontos' not in result_df.columns:
        result_df['Pontos'] = 0
    
    for student, bonus in bonuses.items():
        result_df.loc[result_df['Nome'] == student, 'Pontos'] += bonus
    
    return result_df, pd.DataFrame(weekly_report)

def print_weekly_report(weekly_report):
    """Print a formatted weekly scoring report.
    
    Args:
        weekly_report (pandas.DataFrame): DataFrame containing weekly scoring information
    """
    if weekly_report.empty:
        print("\nNenhum aluno atingiu a sequência de semanas necessária.")
        return
    
    print("\n=== Relatório de Pontuação Semanal ===")
    print(f"Total de alunos premiados: {len(weekly_report['Nome'].unique())}")
    print("\nDetalhes por aluno:")
    
    for _, row in weekly_report.iterrows():
        print(f"\nAluno: {row['Nome']}")
        print(f"Semanas consecutivas: {row['Semanas Consecutivas']}")
        print(f"Bônus recebido: {row['Bônus']} pontos") 