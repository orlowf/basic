import pandas as pd
from .dataframe_utils import create_new_student_row

def process_modalidades(modalidades_df, df_new):
    """Process modalidades data and update the DataFrame."""
    for _, row in modalidades_df.iterrows():
        if row['Nome'] in df_new['Nome'].values:
            df_new.loc[df_new['Nome'] == row['Nome'], 'Aula Coletiva'] += 3
        else:
            nova_linha = create_new_student_row(row['Nome'])
            nova_linha['Aula Coletiva'] = 3
            df_new = pd.concat([df_new, nova_linha], ignore_index=True)
    return df_new 