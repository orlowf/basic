import pandas as pd

def calculate_points(df):
    """Calculate points for each student."""
    df['Pontos'] = df[['Peito', 'Costas', 'Biceps', 'Triceps', 'Perna', 'Aula Coletiva']].sum(axis=1) * 10
    return df

def get_ranking(df, top_n=30):
    """Get the top N students by points."""
    return df.sort_values(by='Pontos', ascending=False).reset_index(drop=True).head(top_n) 