import os
import time
from pathlib import Path
import pandas as pd
from watchdog.events import FileSystemEventHandler

class CSVHandler(FileSystemEventHandler):
    """Handler for CSV file events."""
    
    def __init__(self, db_handler, process_function):
        """Initialize the handler with a database handler and processing function.
        
        Args:
            db_handler: Database handler instance for processing files
            process_function: Function to process CSV files
        """
        self.db_handler = db_handler
        self.process_function = process_function
        self.processed_files = set()
    
    def on_created(self, event):
        """Handle file creation events.
        
        Args:
            event: File system event
        """
        if not event.is_directory and event.src_path.endswith('.csv'):
            self._process_file(event.src_path)
    
    def on_modified(self, event):
        """Handle file modification events.
        
        Args:
            event: File system event
        """
        if not event.is_directory and event.src_path.endswith('.csv'):
            self._process_file(event.src_path)
    
    def _process_file(self, file_path):
        """Process a CSV file if it hasn't been processed recently.
        
        Args:
            file_path (str): Path to the CSV file
        """
        # Skip if file was processed in the last 5 seconds
        current_time = time.time()
        if file_path in self.processed_files:
            return
        
        try:
            print(f"\nNovo arquivo detectado: {file_path}")
            print(f"Última modificação: {pd.Timestamp(os.path.getmtime(file_path), unit='s')}")
            
            # Process the file using the provided function
            if self.process_function(file_path, self.db_handler):
                self.processed_files.add(file_path)
                
                # Remove from processed files after 5 seconds
                def remove_from_processed():
                    time.sleep(5)
                    self.processed_files.discard(file_path)
                
                import threading
                threading.Thread(target=remove_from_processed, daemon=True).start()
                
        except Exception as e:
            print(f"Erro ao processar arquivo {file_path}: {str(e)}")
            print("Detalhes do erro:")
            import traceback
            print(traceback.format_exc())

def get_csv_files(directory):
    """Get all CSV files in the specified directory.
    
    Args:
        directory (str): Path to the directory to search
        
    Returns:
        list: List of paths to CSV files
    """
    return [f for f in Path(directory).glob("*.csv")]

def get_latest_csv(directory):
    """Get the most recently modified CSV file in the directory.
    
    Args:
        directory (str): Path to the directory to search
        
    Returns:
        Path or None: Path to the latest CSV file, or None if no CSV files found
    """
    csv_files = get_csv_files(directory)
    if not csv_files:
        return None
    return max(csv_files, key=os.path.getmtime)

def watch_directory(directory, interval=1):
    """Watch a directory for new or modified CSV files.
    
    Args:
        directory (str): Path to the directory to watch
        interval (int): Time in seconds between checks
        
    Yields:
        Path: Path to the new or modified CSV file
    """
    last_modified = {}
    last_size = {}
    
    while True:
        csv_files = get_csv_files(directory)
        
        for file_path in csv_files:
            current_mtime = os.path.getmtime(file_path)
            current_size = os.path.getsize(file_path)
            
            # If file is new, modified, or size changed
            if (file_path not in last_modified or 
                current_mtime > last_modified[file_path] or 
                current_size != last_size.get(file_path)):
                
                last_modified[file_path] = current_mtime
                last_size[file_path] = current_size
                print(f"Detectada mudança em: {file_path}")
                print(f"Tamanho: {current_size} bytes")
                print(f"Última modificação: {pd.Timestamp(current_mtime, unit='s')}")
                yield file_path
        
        time.sleep(interval)

def get_file_paths(directory):
    """Get the paths for training and modalidades files.
    
    Args:
        directory (str): Base directory containing the CSV files
        
    Returns:
        tuple: (training_file_path, modalidades_file_path)
    """
    training_file = Path(directory) / "Treinos_Academia_Atualizado.csv"
    modalidades_file = Path(directory) / "Modalidade_por_Aluno.csv"
    
    return str(training_file), str(modalidades_file) 