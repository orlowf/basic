import os
import time
from pathlib import Path
import pandas as pd

def get_csv_files(directory):
    """Get all CSV files in the specified directory.
    
    Args:
        directory (str): Path to the directory to search
        
    Returns:
        list: List of paths to CSV files
    """
    return [f for f in Path(directory).glob("*.csv")]

def get_latest_csv(directory):
    """Get the most recently modified CSV file in the directory.
    
    Args:
        directory (str): Path to the directory to search
        
    Returns:
        Path or None: Path to the latest CSV file, or None if no CSV files found
    """
    csv_files = get_csv_files(directory)
    if not csv_files:
        return None
    return max(csv_files, key=os.path.getmtime)

def watch_directory(directory, interval=1):
    """Watch a directory for new or modified CSV files.
    
    Args:
        directory (str): Path to the directory to watch
        interval (int): Time in seconds between checks
        
    Yields:
        Path: Path to the new or modified CSV file
    """
    last_modified = {}
    last_size = {}
    
    while True:
        csv_files = get_csv_files(directory)
        
        for file_path in csv_files:
            current_mtime = os.path.getmtime(file_path)
            current_size = os.path.getsize(file_path)
            
            # If file is new, modified, or size changed
            if (file_path not in last_modified or 
                current_mtime > last_modified[file_path] or 
                current_size != last_size.get(file_path)):
                
                last_modified[file_path] = current_mtime
                last_size[file_path] = current_size
                print(f"Detectada mudança em: {file_path}")
                print(f"Tamanho: {current_size} bytes")
                print(f"Última modificação: {pd.Timestamp(current_mtime, unit='s')}")
                yield file_path
        
        time.sleep(interval)

def get_file_paths(directory):
    """Get the paths for training and modalidades files.
    
    Args:
        directory (str): Base directory containing the CSV files
        
    Returns:
        tuple: (training_file_path, modalidades_file_path)
    """
    training_file = Path(directory) / "Treinos_Academia_Atualizado.csv"
    modalidades_file = Path(directory) / "Modalidade_por_Aluno.csv"
    
    return str(training_file), str(modalidades_file) 