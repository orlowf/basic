import pandas as pd
from .dataframe_utils import create_new_student_row

def process_training_row(row, df):
    """Process a single training row and update the DataFrame.
    
    Args:
        row (pandas.Series): Row containing training data
        df (pandas.DataFrame): DataFrame to update
        
    Returns:
        pandas.DataFrame: Updated DataFrame
    """
    # Get student name and training type
    student_name = row['Nome']
    training_type = row['Treino']
    
    # Check if student exists in DataFrame
    if student_name not in df['Nome'].values:
        # Create new row for student
        df = create_new_student_row(df, student_name)
    
    # Update training counts
    if 'Peito' in training_type:
        df.loc[df['Nome'] == student_name, 'Peito'] += 1
    if 'Costas' in training_type:
        df.loc[df['Nome'] == student_name, 'Costas'] += 1
    if 'Bíceps' in training_type:
        df.loc[df['Nome'] == student_name, 'Biceps'] += 1
    if 'Tríceps' in training_type:
        df.loc[df['Nome'] == student_name, 'Triceps'] += 1
    if 'Perna' in training_type:
        df.loc[df['Nome'] == student_name, 'Perna'] += 1
    if 'Aula Coletiva' in training_type:
        df.loc[df['Nome'] == student_name, 'Aula Coletiva'] += 1
    
    return df 