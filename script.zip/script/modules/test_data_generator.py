import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
import time
import threading

def generate_test_data(output_dir, num_students=5, days_to_generate=30, consecutive_days=14):
    """Generate test data with consecutive training days.
    
    Args:
        output_dir (str): Directory to save the generated files
        num_students (int): Number of students to generate data for
        days_to_generate (int): Number of days to generate data for
        consecutive_days (int): Number of consecutive days to ensure for some students
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate student names
    student_names = [f"Aluno_{i+1}" for i in range(num_students)]
    
    # Generate training types
    training_types = [
        "Peito e Tríceps",
        "Costas e Bíceps",
        "Perna",
        "Aula Coletiva"
    ]
    
    # Generate dates
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days_to_generate)
    all_dates = [start_date + timedelta(days=i) for i in range(days_to_generate)]
    
    # Create data for each student
    data = []
    
    for student in student_names:
        # For the first student, ensure consecutive days
        if student == "Aluno_1":
            # Take the first 'consecutive_days' days
            student_dates = all_dates[:consecutive_days]
        else:
            # For other students, randomly select dates
            num_sessions = np.random.randint(10, 20)  # Random number of training sessions
            student_dates = np.random.choice(all_dates, num_sessions, replace=False)
            student_dates = sorted(student_dates)
        
        # Generate training sessions for each date
        for date in student_dates:
            # Add some random time to the date
            time = timedelta(
                hours=np.random.randint(6, 21),  # Between 6 AM and 9 PM
                minutes=np.random.randint(0, 60),
                seconds=np.random.randint(0, 60)
            )
            datetime_with_time = date + time
            
            # Select random training type
            training = np.random.choice(training_types)
            
            data.append({
                'Nome': student,
                'Treino': training,
                'DataHora': datetime_with_time
            })
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Sort by date
    df = df.sort_values('DataHora')
    
    # Save to CSV
    output_file = os.path.join(output_dir, 'Treinos_Teste_Consecutivos.csv')
    df.to_csv(output_file, index=False)
    
    print(f"\nArquivo de teste gerado: {output_file}")
    print(f"Total de registros: {len(df)}")
    print(f"Período: {df['DataHora'].min()} - {df['DataHora'].max()}")
    print("\nPrimeiras linhas do arquivo:")
    print(df.head())
    
    # Print information about consecutive days
    print("\nInformações sobre dias consecutivos:")
    for student in student_names:
        student_dates = df[df['Nome'] == student]['DataHora'].dt.date.unique()
        student_dates = sorted(student_dates)
        
        # Find consecutive days
        consecutive_count = 1
        max_consecutive = 1
        for i in range(1, len(student_dates)):
            if (student_dates[i] - student_dates[i-1]).days == 1:
                consecutive_count += 1
                max_consecutive = max(max_consecutive, consecutive_count)
            else:
                consecutive_count = 1
        
        print(f"\n{student}:")
        print(f"Total de dias de treino: {len(student_dates)}")
        print(f"Máximo de dias consecutivos: {max_consecutive}")
        if max_consecutive >= consecutive_days:
            print("✓ Aluno atingiu a sequência necessária para bônus!")

def generate_continuous_test_data(output_dir, interval_seconds=15):
    """Continuously generate test data at specified intervals.
    
    Args:
        output_dir (str): Directory to save the generated files
        interval_seconds (int): Time interval between generations in seconds
    """
    def generate_and_save():
        while True:
            try:
                # Generate a unique filename with timestamp
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"Treinos_Teste_{timestamp}.csv"
                output_file = os.path.join(output_dir, filename)
                
                # Generate test data
                generate_test_data(output_dir)
                
                # Rename the file to include timestamp
                os.rename(
                    os.path.join(output_dir, 'Treinos_Teste_Consecutivos.csv'),
                    output_file
                )
                
                print(f"\nNovo arquivo gerado: {filename}")
                time.sleep(interval_seconds)
                
            except Exception as e:
                print(f"Erro ao gerar arquivo de teste: {str(e)}")
                time.sleep(interval_seconds)
    
    # Start the continuous generation in a separate thread
    thread = threading.Thread(target=generate_and_save, daemon=True)
    thread.start()
    return thread 