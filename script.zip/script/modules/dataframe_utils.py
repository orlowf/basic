import pandas as pd

def create_empty_dataframe():
    """Create an empty DataFrame with the required columns.
    
    Returns:
        pandas.DataFrame: Empty DataFrame with columns for student data
    """
    return pd.DataFrame(columns=[
        'Nome',
        'Peito',
        'Costas',
        'Biceps',
        'Triceps',
        'Perna',
        'Aula Coletiva',
        'Pontos'
    ])

def create_new_student_row(student_name):
    """Create a new row for a student.
    
    Args:
        student_name (str): Name of the student
        
    Returns:
        pandas.DataFrame: DataFrame containing the new row
    """
    return pd.DataFrame({
        'Nome': [student_name],
        'Peito': [0],
        'Costas': [0],
        'Biceps': [0],
        'Triceps': [0],
        'Perna': [0],
        'Aula Coletiva': [0],
        'Pontos': [0]
    }) 