import pandas as pd
from datetime import datetime, timedelta

def convert_dates(df):
    """Convert the Date column to datetime format.
    
    Args:
        df (pandas.DataFrame): DataFrame containing the Date column
        
    Returns:
        pandas.DataFrame: DataFrame with converted dates
    """
    try:
        # Check if DataHora column exists
        if 'DataHora' in df.columns:
            df = df.rename(columns={'DataHora': 'Date'})
        elif 'Date' not in df.columns:
            print("Erro: Coluna de data não encontrada. Colunas disponíveis:", df.columns.tolist())
            return None
            
        # Convert to datetime
        df['Date'] = pd.to_datetime(df['Date'])
        return df
    except Exception as e:
        print(f"Erro ao converter datas: {str(e)}")
        return None

def create_frequency_map(df):
    """Create a map of unique student-date pairs.
    
    Args:
        df (pandas.DataFrame): DataFrame containing Name and Date columns
        
    Returns:
        pandas.DataFrame: DataFrame with unique student-date pairs
    """
    if df is None:
        return pd.DataFrame()
    
    # Convert dates to date only (remove time component)
    df['Date'] = df['Date'].dt.date
    return df[['Nome', 'Date']].drop_duplicates().sort_values(['Nome', 'Date'])

def find_consecutive_days(dates, required_days=14):
    """Find sequences of consecutive days in a list of dates.
    
    Args:
        dates (list): List of datetime objects
        required_days (int): Number of consecutive days required
        
    Returns:
        list: List of tuples (start_date, end_date) for each sequence found
    """
    if len(dates) < required_days:
        return []
    
    sequences = []
    current_sequence = [dates[0]]
    
    for i in range(1, len(dates)):
        current_date = dates[i]
        previous_date = current_sequence[-1]
        
        # Check if dates are consecutive
        if (current_date - previous_date).days == 1:
            current_sequence.append(current_date)
        else:
            # If we have enough days, save the sequence
            if len(current_sequence) >= required_days:
                sequences.append((current_sequence[0], current_sequence[-1]))
            # Start a new sequence
            current_sequence = [current_date]
    
    # Check the last sequence
    if len(current_sequence) >= required_days:
        sequences.append((current_sequence[0], current_sequence[-1]))
    
    return sequences

def process_bonus(df, bonus_points=50, required_days=14):
    """Process training frequency and assign bonuses.
    
    Args:
        df (pandas.DataFrame): DataFrame containing training data
        bonus_points (int): Number of bonus points to award
        required_days (int): Number of consecutive days required for bonus
        
    Returns:
        tuple: (updated_df, bonus_report)
    """
    # Convert dates
    df = convert_dates(df)
    if df is None:
        return pd.DataFrame(), pd.DataFrame()
    
    # Create frequency map
    freq_map = create_frequency_map(df)
    if freq_map.empty:
        return df, pd.DataFrame()
    
    # Find students with consecutive days
    bonus_students = {}
    for student in freq_map['Nome'].unique():
        student_dates = freq_map[freq_map['Nome'] == student]['Date'].tolist()
        sequences = find_consecutive_days(student_dates, required_days)
        
        if sequences:
            bonus_students[student] = sequences
    
    # Create bonus report
    bonus_report = []
    for student, sequences in bonus_students.items():
        for start_date, end_date in sequences:
            bonus_report.append({
                'Nome': student,
                'Início': start_date,
                'Fim': end_date,
                'Dias': (end_date - start_date).days + 1
            })
    
    # Create a new DataFrame with the same structure as the original
    result_df = df.copy()
    
    # Apply bonus points
    if 'Pontos' not in result_df.columns:
        result_df['Pontos'] = 0
    
    for student in bonus_students:
        result_df.loc[result_df['Nome'] == student, 'Pontos'] += bonus_points
    
    return result_df, pd.DataFrame(bonus_report)

def print_bonus_report(bonus_report):
    """Print a formatted bonus report.
    
    Args:
        bonus_report (pandas.DataFrame): DataFrame containing bonus information
    """
    if bonus_report.empty:
        print("\nNenhum aluno atingiu a sequência de treinos necessária.")
        return
    
    print("\n=== Relatório de Bônus ===")
    print(f"Total de alunos premiados: {len(bonus_report['Nome'].unique())}")
    print("\nDetalhes por aluno:")
    
    for _, row in bonus_report.iterrows():
        print(f"\nAluno: {row['Nome']}")
        print(f"Período: {row['Início'].strftime('%d/%m/%Y')} - {row['Fim'].strftime('%d/%m/%Y')}")
        print(f"Dias consecutivos: {row['Dias']}") 