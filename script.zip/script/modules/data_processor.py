import pandas as pd

def process_training_data(file_path):
    """Process the training data from a CSV file.
    
    Args:
        file_path (str): Path to the CSV file
        
    Returns:
        pandas.DataFrame: Processed DataFrame
    """
    try:
        # Read the CSV file
        df = pd.read_csv(file_path)
        
        # Ensure required columns exist
        required_columns = ['Nome', 'Treino', 'DataHora']
        if not all(col in df.columns for col in required_columns):
            print(f"Erro: Colunas necessárias não encontradas. Colunas encontradas: {df.columns.tolist()}")
            return None
        
        return df
        
    except Exception as e:
        print(f"Erro ao processar arquivo: {str(e)}")
        return None 